package com.NotificationScheduler.Publisher;

import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.NotificationScheduler.Entity.BidDetailEntity;
import com.NotificationScheduler.Entity.SchedulerDataEntity;
import com.NotificationScheduler.QueueConfig.RabbitMQConfig;
import com.NotificationScheduler.util.JSONUtil;

import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.core.Message;



@Component
public class SendMailPublisher {
	
	@Autowired
	private RabbitTemplate rabbitTemplate;
	
	@Autowired
	private JSONUtil jsonUtil;

	@Autowired
	private RabbitMQConfig rabbitMqQueueConfig;

	private static final Logger logger = LoggerFactory.getLogger(SendMailPublisher.class);

	public String sendMessage(BidDetailEntity bidDetail, String productName,Long bidOfferId) {

		logger.debug("Sending message...");
		MessageProperties messageProperties = new MessageProperties();

		String requestGuid = UUID.randomUUID().toString();
		SchedulerDataEntity schedulerData=new SchedulerDataEntity();
		schedulerData.setBidPrice(bidDetail.getBidPrice());		
		schedulerData.setBuyerName(bidDetail.getBuyerName());
		schedulerData.setEmailId(bidDetail.getBuyerEmail());
		schedulerData.setProductName(productName);
		schedulerData.setRequestId(requestGuid);	
		schedulerData.setBidOfferId(bidOfferId);
		messageProperties.setCorrelationId(requestGuid.getBytes());
		messageProperties.setCorrelationIdString(requestGuid.toString());
		String SchedulerDataJsonString = jsonUtil.getJsonString(schedulerData);
		Message message = new Message(SchedulerDataJsonString.getBytes(), messageProperties);
		
		
		System.out.println("Sending message  " + productName);
		rabbitTemplate.convertAndSend(rabbitMqQueueConfig.getRewardsDispatcherQueue(), message);
		logger.debug("sent message...");		

		return productName;

	}

}
