package com.NotificationScheduler.Listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.NotificationScheduler.Entity.SchedulerDataEntity;
import com.NotificationScheduler.Service.EmailService;
import com.NotificationScheduler.util.JSONUtil;


@Service
public class SendMailListener {
	
	private static final Logger logger = LoggerFactory.getLogger(SendMailListener.class);
	
	@Autowired
	private JSONUtil jsonUtil;
	
	@Autowired
	private EmailService emailService;



	@RabbitListener(queues = "#{'${rewards.dispatcher.queue.name}'}")
	public void receiveMessage(Message schedulerData) {
        
		logger.debug("Receving message...");		
		System.out.println("body" + new String(schedulerData.getBody()));
		String jsonResponse = new String(schedulerData.getBody());
		SchedulerDataEntity emailData = jsonUtil.getJsonBean(jsonResponse, SchedulerDataEntity.class);
		emailService.sendMail(emailData);
		
	}

}
