package com.NotificationScheduler.QueueConfig;

import org.springframework.amqp.core.Queue;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class RabbitMQConfig {

	
	@Value("#{'${rewards.dispatcher.queue.name}'}")
	private String emailDispatcherQueue;
	
	@Bean
	public Queue rewardsDispatcherQueue() {
		return new Queue(emailDispatcherQueue,false);
	}
	
	public String getRewardsDispatcherQueue() {
		return emailDispatcherQueue;
	}

	public void setRewardsDispatcherQueue(String emailDispatcherQueue) {
		this.emailDispatcherQueue = emailDispatcherQueue;
	}
}
