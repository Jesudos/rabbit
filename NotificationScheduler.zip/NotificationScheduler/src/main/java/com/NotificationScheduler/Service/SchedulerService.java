package com.NotificationScheduler.Service;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import com.NotificationScheduler.Entity.BidDetailEntity;
import com.NotificationScheduler.Entity.BidOfferEntity;
import com.NotificationScheduler.Entity.ProductEntity;
import com.NotificationScheduler.Publisher.SendMailPublisher;


@Component
public class SchedulerService {
	
	@Autowired
	private RestTemplate restTemplate;
	
	 @Autowired
	 private SendMailPublisher mailQueuepublisher;	 

	private static final Logger log = LoggerFactory.getLogger(SchedulerService.class);
	 
	 @Scheduled(cron = "0 0/30 * * * ?")
	 
	 public void printProductName(){
		 BidOfferEntity[] bidOffer= restTemplate.getForObject("http://BIDOFFERMANAGEMENT/bidOffer", BidOfferEntity[].class);
		 log.info("The ProductName is");
		List<BidOfferEntity> bidOfferData= Arrays.asList(bidOffer);
		
		 for (int i = 0; i < bidOfferData.size(); i++) {
			 log.info("The BidOffer ID is from DB "+ bidOfferData.get(i).bidOfferId +"  enda date of "+bidOfferData.get(i).endDate); 
			 Calendar calendar = Calendar.getInstance();
			 Timestamp currentTimestamp = new java.sql.Timestamp(calendar.getTime().getTime());
			
			 if(currentTimestamp.after(bidOfferData.get(i).endDate) && ! bidOfferData.get(i).isProcessed) {
				 log.info("currentTimestamp   "+ currentTimestamp); 
				 ProductEntity productData = restTemplate.getForObject("http://PRODUCTMANAGEMENT/product/"+bidOfferData.get(i).getProductId(), ProductEntity.class);
				 getMaxBidDetailsForBidOffer(bidOfferData.get(i).bidOfferId,productData.productName);
			 }
			 
			 
	      }
		 
	 }
	 
	 public void getMaxBidDetailsForBidOffer(Long id,String productName){
		 
		   
				 BidDetailEntity[] 	maxPriceObj= restTemplate.getForObject("http://BIDDETAILMANAGEMENT/bidDetail/bidOfferId/"+id, BidDetailEntity[].class);
				 List<BidDetailEntity> maxPriceData=Arrays.asList(maxPriceObj);
		 float maxPrice=0;
		 BidDetailEntity maxPriceBidData = null;
		 for (int i = 0; i < maxPriceData.size(); i++) {
			 if(maxPrice<maxPriceData.get(i).bidPrice){
				 maxPrice=maxPriceData.get(i).bidPrice;
				 maxPriceBidData=maxPriceData.get(i);
				 
			 } 
		 }
		 mailQueuepublisher.sendMessage(maxPriceBidData, productName,id);
		 
	 }
	
}
