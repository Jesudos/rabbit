package com.NotificationScheduler.Service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.NotificationScheduler.Config.ApplicationEnvVariables;
import com.NotificationScheduler.Entity.BidDetailEntity;
import com.NotificationScheduler.Entity.BidOfferEntity;
import com.NotificationScheduler.Entity.SchedulerDataEntity;
import com.sendgrid.SendGrid;
import com.sendgrid.SendGridException;

@Service
public class EmailService {

	 private static final Logger log = LoggerFactory.getLogger(EmailService.class);
	 @Autowired
	 public ApplicationEnvVariables  applicationEnvVaribales;
	 
	 @Autowired
		private RestTemplate restTemplate;
	 
	 public String sendMail(SchedulerDataEntity emailData){
		 
		String sendGridUserName= applicationEnvVaribales.getSendGridUserName();
		String sendGridPassword =applicationEnvVaribales.getSendGridPassword();
		
		System.out.println("sendGridPasswordresponse.getMessage()"+sendGridPassword);
		

	 SendGrid sendgrid = new SendGrid(sendGridUserName,sendGridPassword);	
	 SendGrid.Email welcomeMail = new SendGrid.Email();
	 welcomeMail.addTo(""+emailData.getEmailId()+"");
	 welcomeMail.addToName("User-san");
	 welcomeMail.setFrom("welcome@example.com");
	 welcomeMail.setSubject("You have Won the Bid!");
	 welcomeMail.setText("Hi " +emailData.getBuyerName() +" , Thank you for your interest in the Product! You have won the Product, "+emailData.getProductName() +" for bid price of "+  emailData.getBidPrice()+" . We will Sending notification once It is Packed. Thanks You");

	 try {
	     SendGrid.Response response = sendgrid.send(welcomeMail);
	     System.out.println(response.getMessage());
	     log.info("mail Sent Successfully to - "+ emailData.getBuyerName()	     
		 );
	     log.info("Request id  - "+ emailData.getRequestId()	     
	    		 );
	     restTemplate.put("http://BIDOFFERMANAGEMENT/bidOffer/updateProcessStatus/"+emailData.getBidOfferId(), null, BidOfferEntity.class);
	     return "Success";
	 } catch (SendGridException sge) {
		 
	     sge.printStackTrace();
	     return "Error";
	     
	 }
	 }
}
