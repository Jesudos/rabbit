package com.NotificationScheduler.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="BID_DETAILS")
public class BidDetailEntity {
	
	@Id
	@Column(name="BID_ID")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="bidDetail_sequence")
	@SequenceGenerator(
		name="bidDetail_sequence",
		sequenceName="bidDetail_sequence",
		allocationSize=1
	)
	public Long bidId;
	
	@Column(name="BID_OFFER_ID")
	public Long bidOfferId;
	
	@Column(name="BID_PRICE")
	public float bidPrice;
	
	@Column(name="BUYER_NAME")
	public String buyerName;
	
	@Column(name="BUYER_EMAIL")
	public String buyerEmail;	
	

	@Column(name="IS_SELECTED")
	public boolean isSelected;
	
	@Column(name="IS_PROCESSED")
	public boolean isProcessed;
	
	public BidDetailEntity()
	{
		
		
	}
	public BidDetailEntity(Long bidId, Long bidOfferId, float bidPrice, String buyerName, String buyerEmail,
			boolean isSelected, boolean isProcessed) {
		super();
		this.bidId = bidId;
		this.bidOfferId = bidOfferId;
		this.bidPrice = bidPrice;
		this.buyerName = buyerName;
		this.buyerEmail = buyerEmail;
		this.isSelected = isSelected;
		this.isProcessed = isProcessed;
	}
		

	public Long getBidId() {
		return bidId;
	}

	public void setBidId(Long bidId) {
		this.bidId = bidId;
	}

	public Long getBidOfferId() {
		return bidOfferId;
	}

	public void setBidOfferId(Long bidOfferId) {
		this.bidOfferId = bidOfferId;
	}

	public float getBidPrice() {
		return bidPrice;
	}

	public void setBidPrice(float bidPrice) {
		this.bidPrice = bidPrice;
	}

	public String getBuyerName() {
		return buyerName;
	}

	public void setBuyerName(String buyerName) {
		this.buyerName = buyerName;
	}

	public String getBuyerEmail() {
		return buyerEmail;
	}

	public void setBuyerEmail(String buyerEmail) {
		this.buyerEmail = buyerEmail;
	}

	public boolean isSelected() {
		return isSelected;
	}

	public void setSelected(boolean isSelected) {
		this.isSelected = isSelected;
	}

	public boolean isProcessed() {
		return isProcessed;
	}

	public void setProcessed(boolean isProcessed) {
		this.isProcessed = isProcessed;
	}
	

}
