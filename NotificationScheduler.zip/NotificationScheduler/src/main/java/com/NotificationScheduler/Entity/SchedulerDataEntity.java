package com.NotificationScheduler.Entity;




public class SchedulerDataEntity {
	
	
	public String productName;
	
    public String emailId;
	
	public String buyerName;
	
	public float bidPrice;
	
	public String requestId;

	public Long bidOfferId;
	

	public SchedulerDataEntity(String productName, String emailId, String buyerName, float bidPrice,String requestId,Long bidOfferId) {
		super();
		this.productName = productName;
		this.emailId = emailId;
		this.buyerName = buyerName;
		this.bidPrice = bidPrice;
		this.requestId = requestId;
		this.bidOfferId = bidOfferId;
	}
	
	public SchedulerDataEntity() {
		// TODO Auto-generated constructor stub
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getBuyerName() {
		return buyerName;
	}

	public void setBuyerName(String buyerName) {
		this.buyerName = buyerName;
	}

	public float getBidPrice() {
		return bidPrice;
	}

	public void setBidPrice(float bidPrice) {
		this.bidPrice = bidPrice;
	}

	
	
    public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	
	public Long getBidOfferId() {
		return bidOfferId;
	}

	public void setBidOfferId(Long bidOfferId) {
		this.bidOfferId = bidOfferId;
	}
	

}
