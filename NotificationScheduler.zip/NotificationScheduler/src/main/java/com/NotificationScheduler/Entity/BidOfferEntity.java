package com.NotificationScheduler.Entity;


import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="BID_OFFER")
public class BidOfferEntity {
	
	@Id
	@Column(name="BID_OFFER_ID")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="bidOffer_sequence")
	@SequenceGenerator(
		name="bidOffer_sequence",
		sequenceName="bidOffer_sequence",
		allocationSize=1
	)
	public Long bidOfferId;
	
	@Column(name="BID_OFFER_PRICE")
	public float bidOfferPrice;
	
	@Column(name="START_DATE")
	public Timestamp startDate;
	
	@Column(name="END_DATE")
	public Timestamp endDate;
	
	@Column(name="PRODUCT_ID")
	public Long productId;
	
	@Column(name="IS_PROCESSED")
	public boolean isProcessed;
	

	public BidOfferEntity()
	{
		
	}

	public BidOfferEntity(Long bidOfferId, float bidOfferPrice, Timestamp startDate, Timestamp endDate, Long productId,boolean isProcessed) {
		super();
		this.bidOfferId = bidOfferId;
		this.bidOfferPrice = bidOfferPrice;
		this.startDate = startDate;
		this.endDate = endDate;
		this.productId = productId;
		this.isProcessed=isProcessed;
		
	}

	public Long getProductId() {
		return productId;
	}



	public void setProductId(Long productId) {
		this.productId = productId;
	}



	public Long getBidOfferId() {
		return bidOfferId;
	}
	
	

	public void setBidOfferId(Long bidOfferId) {
		this.bidOfferId = bidOfferId;
	}

	public float getBidOfferPrice() {
		return bidOfferPrice;
	}

	public void setBidOfferPrice(float bidOfferPrice) {
		this.bidOfferPrice = bidOfferPrice;
	}

	public Timestamp getStartDate() {
		return startDate;
	}

	public void setStartDate(Timestamp startDate) {
		this.startDate = startDate;
	}

	public Timestamp getEndDate() {
		return endDate;
	}

	public void setEndDate(Timestamp endDate) {
		this.endDate = endDate;
	}

	public boolean isProcessed() {
		return isProcessed;
	}

	public void setProcessed(boolean isProcessed) {
		this.isProcessed = isProcessed;
	}

	

}