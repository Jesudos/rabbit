package com.NotificationScheduler.Entity;


import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="PRODUCT_DETAILS")
public class ProductEntity {
	
	@Id
	@Column(name="PRODUCT_ID")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="product_sequence")
	@SequenceGenerator(
		name="product_sequence",
		sequenceName="product_sequence",
		allocationSize=1
	)
	public Long  productId;	

	@Column(name="PRODUCT_NAME")
	public String productName;
	
	@Column(name="DESCRIPTION")
	public String description;
	
	@Column(name="QUANTITY")
	public int quantity;
	
	@Column(name="UNIT")
	public String unit;
	
	@Column(name="STARTING_PRICE")
	public float startingPrice;
	
	@Column(name="STATUS")
	public String status;
	
	@Column(name="CREATED_DATE")
	public Timestamp  createdDate;
	
	@Column(name="CREATED_BY")
	public String createdBy;
	
	public ProductEntity()
	{
		
	}
	
	public ProductEntity(Long productId, String productName, String description, int quantity, String unit,
			float startingPrice, String status, Timestamp createdDate, String createdBy) {
		super();
		this.productId =  productId;
		this.productName = productName;
		this.description = description;
		this.quantity = quantity;
		this.unit = unit;
		this.startingPrice = startingPrice;
		this.status = status;
		this.createdDate = createdDate;
		this.createdBy = createdBy;
	}


	public Long getProductId() {
		return productId;
	}

	
	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public float getStartingPrice() {
		return startingPrice;
	}

	public void setStartingPrice(float startingPrice) {
		this.startingPrice = startingPrice;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	
}
