package com.NotificationScheduler.Config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ApplicationEnvVariables {
	
	@Value("${spring.sendgrid.password}")
	private String sendGridPassword;
	
	public String getSendGridPassword() {
		return sendGridPassword;
	}

	public void setSendGridPassword(String sendGridPassword) {
		this.sendGridPassword = sendGridPassword;
	}

	public String getSendGridUserName() {
		return sendGridUserName;
	}

	public void setSendGridUserName(String sendGridUserName) {
		this.sendGridUserName = sendGridUserName;
	}

	@Value("${spring.sendgrid.username}")
	private String sendGridUserName;

}
